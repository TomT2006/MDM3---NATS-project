Three UML views: classes, aircraft states and successful dispatch sequence.
Open .svg to view; open .drawio at https://app.diagrams.net/ to edit.
Simplified views omit logging and some helper records. No desktop download needed.
