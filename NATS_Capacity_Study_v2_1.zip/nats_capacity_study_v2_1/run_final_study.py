"""Reproducible bounded search, then fresh-seed confirmation of a shortlist."""
from pathlib import Path
from dataclasses import replace
import json
import argparse
from optimisation import make_candidates,run_candidates,rank
from model import example_config


def run(destination, workers=6, screen_reps=12, confirm_reps=80):
    folder=Path(destination);base=example_config()
    candidates,invalid=make_candidates(base,fleets=(8,10,12),stands=(2,3,4),intervals=(15,30))
    print(f'{len(candidates)} valid configurations; {len(invalid)} rejected before simulation.',flush=True)
    screening=run_candidates(candidates,range(50001,50001+screen_reps),folder/'screening',workers=workers)
    screening['source_stages']=[dict(folder='screening',fingerprint=screening['fingerprint'],seeds=screening['seeds'])]
    screening['fingerprint_scope']='Initial stage only; each source stage has its own fingerprint and seed list.'
    expanded=False
    if not any(x['summary']['eligible'] for x in screening['candidates']):
        # Expand resources, not acceptance thresholds, when the initial box fails.
        extra,bad=make_candidates(base,fleets=(14,16),stands=(5,6),intervals=(15,),
            charging={'distributed':{p:1 for p in base.port_names},
                      'double':{p:2 for p in base.port_names}})
        extension=run_candidates(extra,range(52001,52001+screen_reps),folder/'expanded_screening',workers=workers)
        screening['source_stages'].append(dict(folder='expanded_screening',fingerprint=extension['fingerprint'],seeds=extension['seeds']))
        candidates+=extra;invalid+=bad;expanded=True
        screening['candidates']+=extension['candidates']
        from optimisation import pareto_ids,PREFERENCE_SCENARIOS
        screening['pareto']=pareto_ids(screening['candidates'])
        screening['rankings']={k:rank(screening['candidates'],w) for k,w in PREFERENCE_SCENARIOS.items()}
    (folder/'combined_screening.json').write_text(json.dumps(screening,indent=2)+'\n')
    # Take each preference scenario's winner, then distinct Pareto alternatives.
    names=[]
    for ranking in screening['rankings'].values():
        if ranking and ranking[0][1] not in names:names.append(ranking[0][1])
    for _,name in rank(screening['candidates']):
        if name in screening['pareto'] and name not in names and len(names)<4:names.append(name)
    if not names:
        names=[x['id'] for x in sorted(screening['candidates'],
               key=lambda x:x['summary']['metrics'].get('timely',{}).get('mean',0),reverse=True)[:3]]
    # Always independently test the existing baseline, even if screening fails.
    baseline_name='F8_S4_reference_T30'
    if baseline_name not in names:names.append(baseline_name)
    chosen=[(n,c) for n,c in candidates if n in names]
    print('Shortlist:',names,flush=True)
    confirmation=run_candidates(chosen,range(61001,61001+confirm_reps),folder/'final_confirmation',
                                 workers=workers,confirmation=True)
    # Fixed infrastructure and fleet: lower design demand and an overload case.
    # These rows use independent seeds, separately from search/confirmation.
    baseline_rates=[(f'baseline_{rate:g}',replace(base,total_demand_per_hour=rate)) for rate in (12,24,36,48,72)]
    capacity=run_candidates(baseline_rates,range(70001,70031),folder/'capacity',workers=workers,confirmation=True)
    plan=dict(screen_reps=screen_reps,confirm_reps=confirm_reps,invalid=invalid,expanded_after_no_feasible=expanded,
        shortlisted=names,design_demand_per_hour=36,original_baseline=baseline_name,
        note='Joint finite grid; screening and confirmation seeds are disjoint. No global optimum claim.')
    folder.mkdir(parents=True,exist_ok=True)
    (folder/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    print('Final study complete.',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('optimisation_data'))
    parser.add_argument('--workers',type=int,default=6)
    args=parser.parse_args();run(args.output,args.workers)
