"""Report figures: short labels, vector originals and 300-dpi PNG copies."""
from pathlib import Path
import json
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter,MaxNLocator,FixedLocator

BLUE='#0072B2'; ORANGE='#D55E00'; GREEN='#009E73'; PURPLE='#A05D92'; GREY='#6B7280'
COLORS=(BLUE,ORANGE,GREEN,PURPLE,'#E69F00','#56B4E9')
CAPTIONS={}


def configure():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
        'axes.labelsize':10,'axes.titlesize':11,'xtick.labelsize':9,'ytick.labelsize':9,
        'legend.fontsize':9,'axes.spines.top':False,'axes.spines.right':False,
        'axes.prop_cycle':plt.cycler(color=COLORS),'axes.grid':False,
        'lines.linewidth':1.4,'lines.markersize':4.5,'savefig.facecolor':'white',
        'figure.facecolor':'white','pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none'})


def figure(ncols=1,nrows=1,height=None,sharey=False,sharex=False):
    configure()
    # Single-column charts remain legible at normal report-page width.
    return plt.subplots(nrows,ncols,figsize=(6.6 if ncols==1 else 9.2,
                        height or 3.8*nrows),layout='constrained',sharey=sharey,sharex=sharex)


def percentage(ax,axis='y'):
    (ax.yaxis if axis=='y' else ax.xaxis).set_major_formatter(PercentFormatter(1,decimals=0))


def finish(fig,name,caption):
    folder=Path('figures');folder.mkdir(exist_ok=True)
    stem=Path(name).stem
    for ax in fig.axes:
        ax.grid(axis='y',color='#E5E7EB',linewidth=.6)
        ax.set_axisbelow(True)
        if not isinstance(ax.yaxis.get_major_locator(),(FixedLocator,MaxNLocator)):
            ax.yaxis.set_major_locator(MaxNLocator(nbins=6))
    for suffix in ('png','pdf','svg'):
        fig.savefig(folder/f'{stem}.{suffix}',dpi=300,bbox_inches='tight',pad_inches=.08)
    CAPTIONS[stem]=caption
    (folder/'captions.json').write_text(json.dumps(CAPTIONS,indent=2)+'\n')
    plt.show()
    plt.close(fig)


def errorbars(ax,x,stats,label=None,**kwargs):
    import numpy as np
    mean=np.array([s['mean'] for s in stats]);lo=np.array([s['low'] for s in stats]);hi=np.array([s['high'] for s in stats])
    ax.errorbar(x,mean,yerr=[np.maximum(0,mean-lo),np.maximum(0,hi-mean)],
                marker='o',capsize=3,label=label,**kwargs)
