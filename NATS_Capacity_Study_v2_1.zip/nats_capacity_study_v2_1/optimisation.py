"""Dimensionless configuration ranking, separate from overload and dispatch.

Requirements are checked before ranking. Weights express declared preferences,
not prices or quantities learned from simulation. No simulations start on import.
"""
from dataclasses import dataclass, asdict, replace
from pathlib import Path
from hashlib import sha256
from itertools import product
from concurrent.futures import ProcessPoolExecutor
import json
import math
import numpy as np
from model import Simulation, example_config
from results import audit, measurements
from overload import passenger_arrivals, cost_components, queue_trace, detect_overload, OverloadRule
from uncertainty import bootstrap_mean, exact_probability
from experiments import serialise


@dataclass(frozen=True)
class Objective:
    wait_reference_min: float = 60.0
    fleet_reference: float = 8.0
    stands_reference: float = 16.0
    chargers_reference: float = 3.0
    # Equal importance of one reference-sized change: an explicit benchmark.
    weights: tuple = (1.0, 1.0, 1.0, 1.0)

    def validate(self):
        scales = self.scales()
        if any(not math.isfinite(x) or x <= 0 for x in scales):
            raise ValueError('All reference scales must be finite and positive.')
        if len(self.weights) != 4 or any(not math.isfinite(x) or x < 0 for x in self.weights) or sum(self.weights) <= 0:
            raise ValueError('Four finite nonnegative weights with positive sum required.')

    def scales(self):
        return (self.wait_reference_min, self.fleet_reference,
                self.stands_reference, self.chargers_reference)


@dataclass(frozen=True)
class Requirements:
    completion: float = 0.95
    timely: float = 0.95
    wait_limit_min: float = 60.0
    # Optional operating margins, not universal stability laws.
    max_utilisation: float = None
    max_committed_full_fraction: float = None

    def validate(self):
        for value in (self.completion, self.timely, self.max_utilisation, self.max_committed_full_fraction):
            if value is not None and (not math.isfinite(value) or not 0 <= value <= 1):
                raise ValueError('Service fractions must be in [0,1].')
        if not math.isfinite(self.wait_limit_min) or self.wait_limit_min <= 0:
            raise ValueError('Positive waiting deadline required.')


TERMS = ('wait', 'fleet', 'stands', 'chargers')
PREFERENCE_SCENARIOS = {
    'balanced': (1, 1, 1, 1),
    'passenger_priority': (4, 1, 1, 1),
    'fleet_priority': (1, 4, 1, 1),
    'infrastructure_priority': (1, 1, 2, 2),
}


def calculate_score(row, objective=None):
    """Unclipped ratios. Includes unfinished passengers' observed waiting."""
    objective = objective or Objective()
    objective.validate()
    values = [row[k] for k in ('mean_observed_wait_min', 'fleet', 'stands', 'chargers')]
    if any(v is None or not math.isfinite(v) or v < 0 for v in values):
        raise ValueError('Finite nonnegative measurements required; no-arrival score is undefined.')
    z = np.asarray(values) / np.asarray(objective.scales())
    weights = np.asarray(objective.weights) / sum(objective.weights)
    contributions = dict(zip(TERMS, (z * weights).tolist()))
    return dict(score=float(sum(contributions.values())),
                normalised=dict(zip(TERMS, z.tolist())), contributions=contributions)


def evaluate(sim, requirements=None, rule=None):
    """All offered people remain in denominators. Early stops are ineligible."""
    req = requirements or Requirements(); req.validate()
    c = sim.config; end = float(sim.env.now * c.time_scale_min)
    r = measurements(sim); components = cost_components(sim)
    people = sim.passengers; n = len(people)
    timely = sum(p.departed is not None and
                 float((p.departed-p.arrived)*c.time_scale_min) <= req.wait_limit_min+1e-8 for p in people)
    active_end = min(c.demand_stop_min, end)
    active = measurements(sim, end_min=active_end)
    # The measurement window excludes the artificial end-of-day recovery period.
    utilisation = max(list(active['pad_utilisation'].values()) + list(active['charger_utilisation'].values()))
    full = max(q['committed_full_fraction'] for q in active['aircraft_queues'].values())
    rule = rule or OverloadRule(); rule.validate()
    times = np.arange(0, c.horizon_min+1e-7, rule.sample_min)
    q = queue_trace(sim, times).sum(axis=1)
    event = detect_overload(times, q, rule, c.demand_stop_min)
    row = dict(seed=c.seed, arrivals=n, completed=r['completed'],
        completion=r['completed']/n if n else None, timely=timely/n if n else None,
        mean_observed_wait_min=components['total_wait_min']/n if n else None,
        fleet=c.fleet, stands=sum(c.capacities(p)['stands'] for p in c.port_names),
        chargers=sum(c.capacities(p)['chargers'] for p in c.port_names),
        max_utilisation=utilisation, max_committed_full_fraction=full,
        safety_failure=bool(r['stopped_for_safety']), observed_min=end,
        complete_horizon=end >= c.horizon_min-1e-7,
        overload=event is not None, overload_time_min=event,
        peak_backlog=float(np.nanmax(q)), final_backlog=float(q[np.isfinite(q)][-1]))
    return row


def summarise(rows, requirements=None, objective=None, confirmation=False, resamples=2000):
    """Search uses sample means; confirmation uses pointwise CI bounds.

    Bounds concern expected daily fractions, not a 95% chance of a successful day.
    An incomplete or safety-stopped replication excludes the entire configuration.
    """
    req = requirements or Requirements(); obj = objective or Objective()
    req.validate(); obj.validate()
    if len(rows) < 2 or len({r['seed'] for r in rows}) != len(rows):
        raise ValueError('At least two distinct replications required.')
    reasons = []
    if any(r['safety_failure'] or not r['complete_horizon'] for r in rows):
        reasons.append('Safety stop or incomplete observation')
    if any(r['arrivals'] == 0 for r in rows): reasons.append('No offered passengers in a replication')
    answer = dict(n=len(rows), eligible=False, reasons=reasons, metrics={}, score=None,
                  safety=exact_probability([r['safety_failure'] for r in rows]),
                  overload=exact_probability([r['overload'] for r in rows]),
                  assessment='confirmation' if confirmation else 'screening')
    if reasons: return answer
    for key in ('completion', 'timely', 'mean_observed_wait_min', 'max_utilisation',
                'max_committed_full_fraction', 'peak_backlog', 'final_backlog'):
        answer['metrics'][key] = bootstrap_mean([r[key] for r in rows], resamples=resamples)
    for key, target in (('completion', req.completion), ('timely', req.timely)):
        value = answer['metrics'][key]['low' if confirmation else 'mean']
        if value < target: reasons.append(f'{key} below {target:.0%}')
    for key, limit in (('max_utilisation', req.max_utilisation),
                       ('max_committed_full_fraction', req.max_committed_full_fraction)):
        if limit is not None and answer['metrics'][key]['high' if confirmation else 'mean'] > limit:
            reasons.append(f'{key} above {limit:.0%}')
    scores = [calculate_score(r, obj) for r in rows]
    answer.update(eligible=not reasons, score=bootstrap_mean([s['score'] for s in scores],resamples=resamples),
        normalised={k:float(np.mean([s['normalised'][k] for s in scores])) for k in TERMS},
        contributions={k:float(np.mean([s['contributions'][k] for s in scores])) for k in TERMS})
    return answer


def pareto_ids(items):
    """Non-dominated feasible sample means; not a statistical dominance claim."""
    valid = [x for x in items if x['summary']['eligible']]
    result = []
    for x in valid:
        a = np.array([x['summary']['normalised'][k] for k in TERMS])
        dominated = False
        for y in valid:
            b = np.array([y['summary']['normalised'][k] for k in TERMS])
            if np.all(b <= a+1e-12) and np.any(b < a-1e-12): dominated = True; break
        if not dominated: result.append(x['id'])
    return result


def rank(items, weights=(1,1,1,1)):
    Objective(weights=tuple(weights)).validate()
    w = np.asarray(weights)/sum(weights)
    return sorted([(float(sum(w[i]*x['summary']['normalised'][k] for i,k in enumerate(TERMS))),x['id'])
        for x in items if x['summary']['eligible']], key=lambda pair:(pair[0],pair[1]))


def make_candidates(base=None, fleets=(6,8,10,12), stands=(2,3,4),
                    charging=None, intervals=(30,)):
    """Generic joint grid. Per-port infrastructure is explicit, never inferred."""
    base = base or example_config()
    charging = charging or {'reference':{p:base.capacities(p)['chargers'] for p in base.port_names},
                            'distributed':{p:1 for p in base.port_names}}
    items=[]; invalid=[]
    for fleet, stand, (label, chargers), interval in product(fleets, stands, charging.items(), intervals):
        name=f'F{fleet}_S{stand}_{label}_T{interval:g}'
        overrides={p:{**base.port_overrides.get(p,{}),'stands':stand,'chargers':chargers[p]} for p in base.port_names}
        c=replace(base,fleet=fleet,stands_per_port=stand,port_overrides=overrides,
                  initial_counts=None,timetable_interval_min=interval)
        # Explicit route intervals, if present, stay unchanged and are reported.
        try: c.validate()
        except ValueError as error: invalid.append(dict(id=name,reason=str(error))); continue
        items.append((name,c))
    return items,invalid


def _trial(job):
    name,c,req,rule=job
    arrivals=passenger_arrivals(c,sum(c.demand().values()),c.seed)
    sim=Simulation(c,passenger_arrivals=arrivals).run(); audit(sim)
    return name,evaluate(sim,req,rule)


def run_candidates(candidates, seeds, folder, requirements=None, objective=None,
                   confirmation=False, workers=4, rule=None):
    """Fixed compute budget, common demand streams, inspectable cached raw rows."""
    req=requirements or Requirements(); obj=objective or Objective(); rule=rule or OverloadRule()
    req.validate();obj.validate();rule.validate()
    seeds=tuple(seeds); folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    if len(seeds)<2 or len(set(seeds))!=len(seeds) or any(type(s) is not int or s<0 for s in seeds):
        raise ValueError('At least two distinct nonnegative integer seeds required.')
    if not candidates or len({n for n,c in candidates}) != len(candidates):raise ValueError('Unique candidate names required.')
    configs={n:c for n,c in candidates}
    for c in configs.values():c.validate()
    payload=json.dumps(dict(configs={n:serialise(asdict(c)) for n,c in candidates},seeds=seeds,
                      requirements=asdict(req),rule=asdict(rule)),sort_keys=True).encode()
    for filename in ('model.py','safety.py','queues.py','results.py','overload.py','optimisation.py'):
        payload+=(Path(__file__).parent/filename).read_bytes()
    signature=sha256(payload).hexdigest(); raw_path=folder/'raw_runs.json'
    if raw_path.exists():
        saved=json.loads(raw_path.read_text())
        if saved['fingerprint'] != signature:raise ValueError('Settings/code changed; use a new output folder.')
        groups=saved['groups']
    else:
        groups={n:[] for n,c in candidates}
        jobs=[(n,replace(c,seed=s),req,rule) for n,c in candidates for s in seeds]
        pool=ProcessPoolExecutor(max_workers=workers) if workers>1 else None
        try:
            results=pool.map(_trial,jobs,chunksize=2) if pool else map(_trial,jobs)
            for i,(name,row) in enumerate(results,1):
                groups[name].append(row)
                if i%50==0 or i==len(jobs): print(f'{folder.name}: {i}/{len(jobs)} audited runs',flush=True)
        finally:
            if pool:pool.shutdown()
        raw_path.write_text(json.dumps(dict(fingerprint=signature,groups=groups),indent=1,allow_nan=False)+'\n')
    items=[dict(id=n,config=serialise(asdict(c)),summary=summarise(groups[n],req,obj,confirmation)) for n,c in candidates]
    result=dict(fingerprint=signature,requirements=asdict(req),objective=asdict(obj),seeds=seeds,
        candidates=items,pareto=pareto_ids(items),rankings={k:rank(items,w) for k,w in PREFERENCE_SCENARIOS.items()})
    (folder/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    return result
