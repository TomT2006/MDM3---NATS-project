"""Public cost-optimiser interface. Scores are dimensionless operational penalties.

The legacy 1/200/60/50 score is retained only in archived overload raw records.
Current decisions use optimisation.py and require group-level feasibility checks.
"""
from dataclasses import asdict
from copy import deepcopy
from pathlib import Path
import csv
import math
from model import ScenarioConfig,example_config
from optimisation import (Objective,Requirements,calculate_score,evaluate,summarise,
                          make_candidates,run_candidates,rank,PREFERENCE_SCENARIOS)

BASELINE_PARAMETERS=asdict(example_config())
INTEGER_PARAMETERS={'fleet','seats','stands_per_port','queue_capacity','chargers_per_port','pads_per_port'}


def build_config(parameters,seed):
    values=deepcopy(parameters);overrides=values.pop('port_overrides',{})
    for key in list(values):
        if key.startswith('chargers_') and key!='chargers_per_port':
            port=key[len('chargers_'):]
            if port not in values['port_names']:raise ValueError('Unknown port.')
            overrides.setdefault(port,{})['chargers']=values.pop(key)
    values.update(port_overrides=overrides,seed=int(seed))
    c=ScenarioConfig(**values);c.validate();return c


def get_sweep_values(parameter,values,multipliers,baseline):
    selected=list(values) if values is not None else [baseline[parameter]*x for x in multipliers]
    if parameter in INTEGER_PARAMETERS or parameter.startswith('chargers_'):
        if any(not math.isfinite(v) or int(v)!=v for v in selected):raise ValueError('Explicit integer values required.')
        selected=[int(v) for v in selected]
    return list(dict.fromkeys(selected))


def calculate_cost(measurements,objective=None):
    """J only; call calculate_score for the four inspectable contributions."""
    return calculate_score(measurements,objective)['score']


def run_parameter_sweep(parameter,values,*,seeds=tuple(range(101,113)),baseline=None,
                        objective=None,requirements=None,folder='custom_sweep',workers=4):
    base=deepcopy(BASELINE_PARAMETERS if baseline is None else baseline)
    candidates=[]
    for value in get_sweep_values(parameter,values,(),base):
        parameters=deepcopy(base);parameters[parameter]=value
        candidates.append((f'{parameter}_{value}',build_config(parameters,seeds[0])))
    return run_candidates(candidates,seeds,folder,requirements,objective,workers=workers)


def write_csv(rows,csv_path):
    """Also used by the historical comparison-regeneration script."""
    if not rows:return
    path=Path(csv_path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
