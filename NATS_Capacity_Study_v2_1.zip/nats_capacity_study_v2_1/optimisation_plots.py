"""Current dimensionless objective and independent confirmation figures."""
import numpy as np
from optimisation import TERMS,rank,calculate_score,Objective
from chart_style import figure,finish,errorbars,percentage,BLUE,ORANGE,GREEN,GREY,PURPLE


def label(item):
    c=item['config']
    charging='1 charger/port' if 'distributed' in item['id'] else ('2 chargers/port' if 'double' in item['id'] else 'Reference charging')
    return f"{c['fleet']} aircraft, {c['stands_per_port']} stands\n{charging}, {c['timetable_interval_min']:g} min"


def screening(data):
    fig,ax=figure();items=data['candidates']
    for eligible,color,name in [(False,'#B8C0CA','Fails screening'),(True,BLUE,'Passes screening')]:
        chosen=[x for x in items if x['summary']['eligible']==eligible and x['summary']['score'] is not None]
        ax.scatter([x['config']['fleet'] for x in chosen],[x['summary']['metrics']['mean_observed_wait_min']['mean'] for x in chosen],c=color,label=name,s=40,alpha=.7)
    ax.set(xlabel='Aircraft in fleet',ylabel='Mean waiting (min)');ax.legend(frameon=False)
    ax.set_xticks(sorted({x['config']['fleet'] for x in items}))
    finish(fig,'18_joint_search',f'Joint configuration screening at 36 passengers/hour with {len(data["seeds"])} replications per candidate, with common seeds within each screening stage and a fresh seed set for the expanded stage. Fleet size, stands, charger placement and timetable are varied together. Blue points meet both mean completion and timely-departure targets; grey points do not. Candidates sharing fleet size may differ in infrastructure or schedule. The two-dimensional view is not the full four-criterion Pareto frontier.')


def confirmation(data):
    items=data['candidates'];names=[label(x) for x in items];y=np.arange(len(items))
    for key,title,stem in [('completion','Completed passengers','19_completion'),('timely','Departed within 60 min','19b_timely_departures')]:
        fig,ax=figure(height=max(3.6,len(items)*.65+1))
        for i,x in enumerate(items):
            if key not in x['summary']['metrics']:continue
            s=x['summary']['metrics'][key];color=BLUE if x['summary']['eligible'] else GREY
            ax.errorbar(s['mean'],i,xerr=[[max(0,s['mean']-s['low'])],[max(0,s['high']-s['mean'])]],fmt='o',color=color,capsize=4)
        ax.axvline(data['requirements'][key],color=ORANGE,ls='--',label='95% requirement')
        ax.set(yticks=y,yticklabels=names,xlabel=title,xlim=((.94,1.005) if key=='completion' else (.65,1.01)));ax.invert_yaxis();percentage(ax,'x');ax.legend(loc='lower left',frameon=False)
        finish(fig,stem,f'Independent confirmation of {title.lower()} using {len(data["seeds"])} fresh replications per shortlisted configuration. Points are mean daily fractions and bars are pointwise 95% whole-run bootstrap confidence intervals. A configuration is eligible only when both service lower bounds reach 95% and no safety stop occurs. Grey points fail at least one requirement. Labels show aircraft, stands per port, charging layout and route timetable interval. Reference charging means two chargers at A, one at C and none at B or D. These are expected daily fractions, not a probability that 95% of operating days succeed.')
    valid=[x for x in items if x['summary']['score'] is not None];fig,ax=figure(height=max(3.6,len(valid)*.65+1));bottom=np.zeros(len(valid))
    for key,name in zip(TERMS,['Passenger waiting','Aircraft provision','Stand provision','Charger provision']):
        values=np.array([x['summary']['contributions'][key] for x in valid]);ax.barh(range(len(valid)),values,left=bottom,label=name,height=.6);bottom+=values
    for i,x in enumerate(valid):
        if not x['summary']['eligible']:
            from matplotlib.patches import Rectangle
            ax.add_patch(Rectangle((0,i-.3),bottom[i],.6,fill=False,hatch='///',edgecolor='#6B7280',linewidth=.5))
    ax.set(yticks=range(len(valid)),yticklabels=[label(x) for x in valid],xlabel='Dimensionless penalty');ax.invert_yaxis()
    ax.legend(ncol=2,loc='upper center',bbox_to_anchor=(.5,1.25),frameon=False,fontsize=8)
    finish(fig,'20_penalty_components','Decomposition of the balanced reference penalty into waiting, aircraft, stands and chargers. Each term has weight 1/4 after normalisation; reference scales are 60 minutes, 8 aircraft, 16 total stands and 3 total chargers. Equal weights mean equal value for a reference-sized change, an explicit illustrative preference rather than an empirically fitted fact. Hatched configurations fail service requirements and are excluded from ranking regardless of score. Completion is a constraint, so no arbitrary unfinished-trip penalty is added.')


def weight_sensitivity(data):
    valid=[x for x in data['candidates'] if x['summary']['eligible']]
    if not valid:return
    fig,ax=figure(height=4.9);grid=np.linspace(0,1,101)
    for x in valid:
        z=x['summary']['normalised'];scores=grid*z['wait']+(1-grid)*(z['fleet']+z['stands']+z['chargers'])/3
        ax.plot(grid,scores,label=label(x))
    ax.axvline(.25,color=GREY,ls='--',lw=1)
    ax.text(.26,.03,'Equal weights',transform=ax.get_xaxis_transform(),color=GREY,fontsize=8)
    ax.set(xlabel='Weight on passenger waiting',ylabel='Dimensionless penalty',xlim=(0,1))
    ax.legend(frameon=False,fontsize=8,ncol=2,loc='lower center',bbox_to_anchor=(.5,1.02))
    finish(fig,'21_weight_sensitivity','Preference sensitivity among independently confirmed feasible configurations. The waiting weight varies from zero to one; the remaining weight is divided equally across aircraft, stands and chargers. Lower curves are preferred at that weight. Crossing points show changes in preference, not changes in the physical simulation. The dashed line is the balanced reference weight 1/4. This one-dimensional sensitivity slice does not cover all possible stakeholder preferences or establish objective probabilities of optimality.')


def capacity(data):
    items=sorted(data['candidates'],key=lambda x:x['config']['total_demand_per_hour']);rates=[x['config']['total_demand_per_hour'] for x in items]
    fig,ax=figure()
    for key,name in [('completion','Completed'),('timely','Departed within 60 min')]:
        errorbars(ax,rates,[x['summary']['metrics'][key] for x in items],label=name)
    ax.axhline(.95,color=GREY,ls='--',label='95% requirement');ax.set(xlabel='Passenger demand (per hour)',ylabel='Share of all passengers',ylim=(0,1.04));percentage(ax);ax.legend(frameon=False)
    finish(fig,'22_service_capacity','Fresh demand sweep for the original eight-aircraft network, original charging layout and 30-minute route timetable. Points and 95% whole-run bootstrap intervals use 30 independent runs per rate. Eligibility is checked using lower confidence bounds for both completion and departure within 60 minutes. This is a finite-day service envelope, not proof of a unique long-run capacity threshold. It can fail service requirements before the sustained-backlog overload event becomes frequent.')


def score_intervals(data):
    paired_improvements(data)
    items=[x for x in data['candidates'] if x['summary']['score'] is not None]
    fig,ax=figure(height=max(3.6,len(items)*.65+1))
    for i,x in enumerate(items):
        s=x['summary']['score'];color=BLUE if x['summary']['eligible'] else GREY
        ax.errorbar(s['mean'],i,xerr=[[max(0,s['mean']-s['low'])],[max(0,s['high']-s['mean'])]],fmt='o',color=color,capsize=4)
    ax.set(yticks=range(len(items)),yticklabels=[label(x) for x in items],xlabel='Dimensionless penalty');ax.invert_yaxis()
    finish(fig,'20b_penalty_intervals',f'Mean balanced operational penalty and pointwise 95% whole-run bootstrap confidence intervals from {len(data["seeds"])} fresh runs per configuration. Blue configurations meet the confirmation requirements; grey configurations are ineligible even if their score is lower. Uncertainty concerns simulation sampling under fixed weights, not uncertainty in stakeholder preferences. Labels show aircraft, stands per port, charging layout and route timetable interval. Reference charging means A=2,C=1 and no chargers at B or D.')


def paired_improvements(data):
    import json
    from pathlib import Path
    rows=json.loads(Path('optimisation_data/paired_comparisons.json').read_text())
    rows=[r for r in rows if r['metric']=='mean_observed_wait_min']
    lookup={x['id']:x for x in data['candidates']}
    fig,ax=figure(height=max(3.6,len(rows)*.7+1))
    for i,r in enumerate(rows):
        ax.errorbar(r['mean'],i,xerr=[[max(0,r['mean']-r['low'])],[max(0,r['high']-r['mean'])]],fmt='o',color=BLUE,capsize=4)
    ax.axvline(0,color=GREY,ls='--');ax.set(yticks=range(len(rows)),yticklabels=[label(lookup[r['B']]) for r in rows],xlabel='Change in mean waiting (min)');ax.invert_yaxis()
    finish(fig,'23_paired_waiting_changes','Change in observed mean passenger waiting relative to the original baseline, using 80 matched fresh-seed run pairs per comparison. Negative values indicate shorter waiting. Error bars are pointwise 95% percentile bootstrap intervals obtained by resampling whole pairs, not individual passengers. The separate CSV gives paired t-test results with Holm adjustment across the eight reported waiting/score contrasts. Comparisons are conditional on the shortlisted designs and do not establish a global optimum.')
