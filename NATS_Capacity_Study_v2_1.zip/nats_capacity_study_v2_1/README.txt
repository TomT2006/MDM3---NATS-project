NATS FIGURE REVISION 2.1 — SIMULATOR, CAPACITY AND DIMENSIONLESS OPERATIONAL OPTIMISATION
=======================================================================
NATS_Capacity_and_Optimisation_v2_1.ipynb is the executed entry point. Extract the complete folder first.
NATS_Capacity_and_Optimisation_v2_1.html shows the notebook without installing or running Python.
NATS_Methods_and_Results_v2_1.pdf and NATS_Methods_and_Results_v2_1.tex explain the final model, mathematics, changes, objective,
weight interpretation, uncertainty and executed results in a neutral report tone.

REPORT FIGURES
NATS_Report_Figures_v2_1.pdf: the 12 selected main-report figures, in narrative order.
NATS_Figure_Guide_v2_1.txt: main-report and supporting figure lists.
figure_selection.json: editable selection and human-readable figure titles.
figures/: PDF vector originals, editable SVG copies and 300-dpi PNG copies.
NATS_Figure_Captions_v2_1.txt: report-ready captions keyed to filenames.
NATS_Figure_Captions_v2_1.tex: ready-to-use LaTeX figure blocks (requires graphicx).
NATS_Figure_Catalogue_v2_1.pdf: all 43 figures, with supporting diagnostics labelled. Use individual PDFs in Overleaf;
use PNG or SVG in Word. Explanations are in captions, not long side labels.

WHAT TO RUN
1. Open NATS_Capacity_and_Optimisation_v2_1.ipynb from this folder. Its saved outputs are already present.
2. Run all notebook cells to reproduce the small demonstrations, tests and plots.
   Large saved experiments are loaded; they are not silently rerun.
3. To regenerate the final bounded search: python run_final_study.py --workers 6
4. To regenerate the original large demand study: python run_overload_study.py
   Then: python analyse_overload.py
5. To run checks alone: python -m unittest discover -v
Install requirements.txt in an existing Python/Jupyter environment. No large
application or Python distribution is bundled. The delivered runtime is recorded
in RUNTIME.txt. Supply a new output folder when changing source or study settings.

CURRENT COST FUNCTION
cost_optimiser_integrated.py is the public interface. calculate_cost(row, objective)
returns the same dimensionless J used in the final tables. optimisation.py defines
references, preference weights, feasibility checks, joint search and summaries.
The notebook explicitly imports this function and recomputes every confirmation
mean from its raw records before plotting it.

J = w_wait * observed_mean_wait/60 + w_fleet * aircraft/8
  + w_stands * total_stands/16 + w_chargers * total_chargers/3.
Weights are normalised to sum to one. The balanced reference assigns 1/4 to each
term; it means equal preference for a reference-sized change. This is a declared
benchmark, not an evidence-derived NATS preference or currency. Alternative weight
scenarios and continuous waiting-weight sensitivity are reported. All reference
scales stay fixed when configurations change. Ratios can exceed one.

Completion and departure within 60 minutes must each reach 95% of all arrivals.
Screening checks sample means. Fresh-seed confirmation checks the lower endpoint
of each pointwise 95% whole-run bootstrap CI and requires no observed safety stop.
A failed/truncated run excludes the entire configuration; successful runs are never
selectively averaged. These criteria concern expected daily fractions, not the
probability of a successful day or a simultaneous confidence statement. Optional
utilisation and committed-pad-full margins are configurable; 85% is not a theorem.

The final optimiser has no per-flight penalty. It does not trade safety against
resource provision, and it does not alter aircraft assignments during a run.
No passenger abandonment is implemented. A waiting target only measures service.
Financial analysis, observed passenger preferences and empirical demand fitting
remain outside scope.

PRESERVED CONTENT
model.py, queues.py, safety.py, results.py and mm1k.py retain aircraft flights,
finite pad queues, central scheduling, swaps, charging and energy checks.
Original saved physical experiments are reused only with matching fingerprints.
Their legacy score fields remain for provenance and are not the final objective.
archive/ contains superseded cost tables and explanations; provided/ preserves the
original groupmate inputs. Neither supplies current ranked recommendations.

CONFIGURATION
ScenarioConfig in model.py controls ports, routes, distances, seats, fleet,
charging, demand, timing and energy. Objective and Requirements in optimisation.py
control scoring and acceptance. make_candidates accepts custom resource grids and
per-port charging maps for any valid network. Scope and computational budgets are
explicit in run_final_study.py. Existing per-route timetable overrides take
precedence over the default timetable, and are recorded in saved configurations.

OPTIONAL EXPORT TOOLS
After regenerating figures, python export_figures.py rebuilds the caption files
and PDF catalogue (requirements-export.txt). Compile the main report with LaTeX
twice to resolve references. The supplied report source and result tables are
editable; calculation outputs should be regenerated when assumptions change.

VERSIONING
This folder is nats_capacity_study_v2_1. Keep it beside the earlier project folder
in GitHub; no old version is overwritten. Python module names remain simple
inside their versioned folder, so relative imports continue to work.
