"""Figures for the physical simulator. Captions carry methodological detail."""
import numpy as np
from matplotlib.ticker import MaxNLocator
from results import measurements,waiting_trace
from experiments import interval
from mm1k import theory,transient
from overload import queue_trace
from chart_style import figure,finish,errorbars,percentage,BLUE,ORANGE,GREEN,PURPLE,GREY

GROUPS={
 'Flight':('takeoff','cruise','landing'),
 'Charging':('charging',),
 'Ground handling':('boarding','unloading','taxi_in','taxi_out'),
 'Pad waiting':('departure_pad_wait','arrival_pad_wait'),
 'Other waiting':('dispatch_wait','charger_wait','ground_delay'),
 'Idle':('idle',)}
PALETTE={'Flight':BLUE,'Charging':'#E69F00','Ground handling':GREEN,
         'Pad waiting':PURPLE,'Other waiting':ORANGE,'Idle':'#CBD5E1'}
STATE_GROUP={s:g for g,states in GROUPS.items() for s in states}


def time_and_queues(sims):
    fig,ax=figure();labels=[str(s.config.headway_min) for s in sims];bottom=np.zeros(len(sims))
    for label,states in GROUPS.items():
        values=np.array([sum(measurements(s)['state_fraction'].get(k,0) for k in states) for s in sims])
        ax.bar(labels,values,bottom=bottom,color=PALETTE[label],label=label,width=.6);bottom+=values
    ax.set(xlabel='Minimum following interval (min)',ylabel='Aircraft time',ylim=(0,1))
    percentage(ax);ax.legend(ncol=3,loc='upper center',bbox_to_anchor=(.5,1.23),frameon=False)
    finish(fig,'01_aircraft_time','Aircraft activity shares for minimum same-route following intervals of 1, 3 and 5 minutes. Shares sum to all available fleet time. Flight includes takeoff, cruise and landing; pad waiting includes airborne landing waits. Ground handling includes boarding, unloading and taxiing. Other waiting includes dispatch, charging queues and additional ground delay. These intervals are separation constraints, not departure frequencies. One illustrative run per interval, with a common demand seed. Identical bars in the reference scenario show that changing this constraint alone does not change that run; they do not establish that headway is irrelevant under other conditions.')
    s=sims[1] if len(sims)>1 else sims[0];t=np.linspace(0,float(s.env.now*s.config.time_scale_min)-1e-6,500)
    fig,ax=figure();ax.plot(t/60,queue_trace(s,t).sum(axis=1));ax.axvline(s.config.demand_stop_min/60,color=GREY,ls='--',label='Arrivals stop')
    ax.set(xlabel='Time (h)',ylabel='Waiting passengers');ax.legend(frameon=False)
    finish(fig,'01b_passenger_queue','Passenger backlog in the illustrative 3-minute-headway run. Backlog counts every arrival that has not departed, including assigned and boarding passengers. Arrivals stop after 10 hours; the following two hours are a recovery window. There is no passenger abandonment.')
    # Use every recorded change, rather than interpolating sampled integer counts.
    events={0.,float(s.env.now)}
    for v in s.ports.values():
        events.update(float(at) for at,_,_ in v.queue.combined_history)
    for _,state,_,a,b in s.log.intervals(s.env.now):
        if state=='charger_wait':events.update((float(a),float(b)))
    t=np.array(sorted(events))*s.config.time_scale_min
    trace=waiting_trace(s,t);fig,axes=figure(nrows=3,height=6.2,sharex=True)
    for ax,i,title,color in zip(axes,(1,2,3),('Aircraft waiting for charging','Aircraft at pads, including service','Future pad reservations'),(BLUE,ORANGE,GREEN)):
        ax.step(t/60,trace[:,i],where='post',color=color,lw=.8)
        ax.set_title(title,loc='left');ax.set(ylabel='Count',ylim=(-.1,max(1,trace[:,i].max())+.6),xlim=(0,t[-1]/60))
        ax.yaxis.set_major_locator(MaxNLocator(nbins=4,integer=True))
        ax.axvline(s.config.demand_stop_min/60,color=GREY,ls=':',lw=.8)
    axes[-1].set_xlabel('Time (h)')
    finish(fig,'01c_aircraft_queues','Network-wide aircraft charging queues, actual pad occupancy and future pad reservations shown separately at every recorded state change. Counts are distinct from passenger backlog; pad occupancy includes service. Vertical dotted lines mark the end of arrivals. Each panel has its own integer scale; no smoothing or time averaging is applied.')


def rotation(sim,hours=4):
    c=sim.config;names=[a.name for a in sim.aircraft];end=min(float(sim.env.now),float(c.time(hours*60)))
    fig,ax=figure(height=4.5)
    for name,state,port,a,b in sim.log.intervals(end):
        ax.broken_barh([(float(a)*c.time_scale_min/60,float(b-a)*c.time_scale_min/60)],
                      (names.index(name)-.35,.7),facecolor=PALETTE[STATE_GROUP[state]])
    from matplotlib.patches import Patch
    ax.set(yticks=range(len(names)),yticklabels=names,xlim=(0,hours),xlabel='Time (h)',ylabel='Aircraft')
    ax.legend(handles=[Patch(color=v,label=k) for k,v in PALETTE.items()],ncol=3,loc='upper center',bbox_to_anchor=(.5,1.23),frameon=False)
    finish(fig,'02_aircraft_rotations','Aircraft activity timeline over the first four hours of the illustrative baseline run. Each row follows a persistent aircraft across successive flights and ground activities. Route identities and nominal-versus-actual assignments are tabulated in notebook section 8. Activity colours match Figure 01; no spatial flight animation is implied.')
    fig,axes=figure(nrows=min(3,len(names)),height=5.6,sharex=True,sharey=True)
    for ax,name in zip(np.atleast_1d(axes),names[:3]):
        events=[]
        for n,t,before,after,fid in sim.log.energy_used:
            if n==name:events.append((float(t),before,after))
        holds=list(sim.log.holding_used)
        for a in sim.aircraft:
            if a.holding is not None:
                start,before,fid=a.holding;holds.append((a.name,start,sim.env.now,before,a.soc,fid))
        for n,a,b,before,after,fid in holds:
            if n==name:events.extend([(float(a),before,before),(float(b),after,after)])
        for n,p,a,b,before,after in sim.log.charges:
            if n==name:
                actual_end=min(float(b),float(sim.env.now));actual_soc=before+(after-before)*(actual_end-float(a))/float(b-a)
                events.extend([(float(a),before,before),(actual_end,actual_soc,actual_soc)])
        x=[0];y=[c.initial_soc]
        for t,before,after in sorted(events):x.extend([t*c.time_scale_min/60]*2);y.extend([before,after])
        x.append(float(sim.env.now)*c.time_scale_min/60);y.append(next(a.soc for a in sim.aircraft if a.name==name))
        ax.plot(x,y,color=BLUE)
        ax.axhline(c.reserve_soc,color=GREY,ls='--',label='Reserve')
        ax.set_title(name,loc='left');ax.set(ylabel='Charge',xlim=(0,hours),ylim=(0,1.03));percentage(ax)
    np.atleast_1d(axes)[0].legend(loc='upper right',frameon=False)
    np.atleast_1d(axes)[-1].set_xlabel('Time (h)')
    finish(fig,'02b_battery_charge','Battery state of charge for the first three aircraft on identical vertical scales. Nominal mission energy is debited at departure, so vertical drops are a bookkeeping convention rather than a physical discharge curve. Charging is linear; airborne waiting draws additional energy. The dashed line is the illustrative 15% reserve, not an aircraft certification limit.')


def resources(sim):
    r=measurements(sim,end_min=min(sim.config.demand_stop_min,float(sim.env.now*sim.config.time_scale_min)))
    ports=list(sim.ports);x=np.arange(len(ports));fig,ax=figure()
    ax.bar(x-.18,[r['pad_utilisation'][p] for p in ports],.36,label='Pad')
    ax.bar(x+.18,[r['charger_utilisation'][p] for p in ports],.36,label='Chargers')
    for i,p in enumerate(ports):
        if not sim.config.capacities(p)['chargers']:
            ax.text(i+.18,.025,'None',ha='center',va='bottom',fontsize=8,color=GREY)
    ax.set(xticks=x,xticklabels=ports,xlabel='Vertiport',ylabel='Utilisation',ylim=(0,1));percentage(ax);ax.legend(frameon=False)
    counts=', '.join(f'{p}: {sim.config.capacities(p)["chargers"]}' for p in ports)
    finish(fig,'03_resource_utilisation',f'Busy time as a fraction of installed resource capacity during active passenger demand, excluding the recovery period. Charger counts are {counts}. A zero bar at an unequipped port means no charger exists; it does not represent spare charging capacity. Pad and charger utilisation are measured separately.')
    fig,ax=figure()
    actual=np.array([r['aircraft_queues'][p]['L'] for p in ports])
    ax.bar(x,actual,.55,label='Actual aircraft')
    ax.bar(x,[r['aircraft_queues'][p]['mean_reservations'] for p in ports],.55,bottom=actual,label='Future reservations')
    ax.plot(x,[sim.ports[p].queue.capacity for p in ports],'_',color=GREY,ms=28,mew=1.5,label='Capacity K')
    ax.set(xticks=x,xticklabels=ports,xlabel='Vertiport',ylabel='Mean occupied places');ax.legend(frameon=False)
    finish(fig,'03b_pad_capacity','Time-averaged actual aircraft occupancy and future reservations during active demand. The actual queue includes aircraft undergoing pad service. The controller enforces actual occupancy plus future reservations no greater than K; a low actual occupancy alone does not establish that another operation can be admitted.')


def benchmark(data):
    for key,label,suffix in [('blocking','Blocked arrivals','blocking'),('Lq','Mean waiting aircraft','queue_length'),('Wq','Mean queue wait (min)','waiting')]:
        fig,ax=figure()
        for K in (1,4,8):
            x=np.array([.5,1,1.5]);stats=[interval([r['metrics'][key] for r in data['benchmark_runs'] if r['K']==K and r['rho']==rho]) for rho in x]
            errorbars(ax,x,stats,label=f'K = {K}',linestyle='none')
            grid=np.linspace(x.min(),x.max(),151)
            ax.plot(grid,[theory(rho,1,K)[key] for rho in grid],ls='--',color=ax.lines[-1].get_color())
        ax.set(xlabel='Offered load, ρ = λ / μ',ylabel=label);ax.legend(frameon=False)
        if key=='blocking':percentage(ax)
        finish(fig,f'04_mm1k_{suffix}',f'Controlled M/M/1/K verification for {label.lower()}. Points are means and 95% Student-t confidence intervals from {data["benchmark_reps"]} independent runs per setting; dashed lines are exact stationary theory. Each run lasts {data["benchmark_duration_min"]:g} minutes with {data["benchmark_warmup_min"]:g} minutes of warm-up. Service rate is one aircraft operation per minute. The same pad-queue implementation is used by the physical network, whose scheduled aircraft arrivals and reservations do not satisfy all exact M/M/1/K assumptions.')


def transient_plot():
    x=np.linspace(0,25,101);p=transient(1,1,4,x);fig,ax=figure()
    for n in range(5):ax.plot(x,p[:,n],label=f'n = {n}')
    ax.axhline(.2,ls=':',color=GREY);ax.set(xlabel='Time (min)',ylabel='State probability',ylim=(0,1));ax.legend(ncol=3,frameon=False)
    finish(fig,'05_transient','Transient state probabilities for an initially empty exact M/M/1/K queue with arrival and service rates both one per minute and K = 4. Fixed rates do not imply a stationary initial state. The probabilities converge to 1/5 for each of the five states; the dotted line marks that stationary value.')


def capacity(data):
    for group,label in [('demand','Passenger demand (per hour)'),('fleet','Aircraft in fleet')]:
        levels=sorted({r['level'] for r in data['network_runs'] if r['group']==group});fig,ax=figure()
        for key,name in [('served_fraction','Completed'),('timely_fraction','Departed within 60 min')]:
            stats=[interval([r['metrics'][key] for r in data['network_runs'] if r['group']==group and r['level']==v]) for v in levels]
            errorbars(ax,levels,stats,label=name)
        ax.axhline(.95,color=GREY,ls='--',label='95% target');ax.set(xlabel=label,ylabel='Share of all passengers',ylim=(0,1.06));percentage(ax);ax.legend(frameon=False)
        finish(fig,f'06_capacity_{group}',f'Original {group} experiment: means and 95% Student-t intervals across five runs per setting. Completion and departure within 60 minutes use all offered passengers as their denominator; the dashed line is an illustrative requirement. Demand is active for ten hours and outcomes are observed for twelve. Seats, resource policy and route timetable remain fixed. These small original experiments are retained for continuity; the final optimisation uses independent screening and confirmation.')


def sensitivity(data):
    for group,label in [('K','Pad capacity K'),('delay','Mean ground delay (min)')]:
        levels=sorted({r['level'] for r in data['network_runs'] if r['group']==group});fig,ax=figure()
        for key,name in [('served_fraction','Completed'),('timely_fraction','Departed within 60 min')]:
            errorbars(ax,levels,[interval([r['metrics'][key] for r in data['network_runs'] if r['group']==group and r['level']==v]) for v in levels],label=name)
        ax.set(xlabel=label,ylabel='Share of all passengers',ylim=(0,1.06));percentage(ax);ax.legend(frameon=False)
        ax.set_xticks(levels)
        finish(fig,f'07_sensitivity_{group}',f'Passenger outcomes under the original {group} sensitivity experiment. Means and 95% Student-t intervals use five independent replications per setting. Changing K also changes conservative reservation and energy-planning allowances; this is not an isolated change to queue storage. Additional ground delays occur after unloading.')


def reliability(sim):
    c=sim.config;waits=sorted(float(p.departed-p.arrived)*c.time_scale_min for p in sim.passengers if p.departed is not None)
    fig,ax=figure();ax.step(waits,np.arange(1,len(waits)+1)/len(sim.passengers),where='post')
    ax.axvline(c.wait_target_min,color=GREY,ls='--',label='60-minute target');ax.set(xlabel='Waiting time (min)',ylabel='Share departed',ylim=(0,1.03));percentage(ax);ax.legend(frameon=False)
    finish(fig,'08_passenger_waiting','Cumulative fraction of all offered passengers who departed within each waiting duration in the illustrative baseline run. Passengers not departed at the observation cutoff remain in the denominator, so the curve may end below 100%. The vertical line is the project waiting target, not an abandonment deadline.')
    routes=list(sim.routes)[:3];fig,axes=figure(nrows=len(routes),height=5.8,sharex=True,sharey=True);gaps=[]
    for ax,route in zip(np.atleast_1d(axes),routes):
        times=sorted(float(f.departed)*c.time_scale_min for f in sim.flights if f.kind=='service' and f.departed is not None and (f.route.origin,f.route.dest)==route)
        if len(times)>1:
            gaps.extend(np.diff(times));ax.scatter(np.array(times[1:])/60,np.diff(times),color=BLUE,s=24)
        interval=c.service_intervals_min.get(route,c.timetable_interval_min);gaps.append(interval)
        ax.axhline(interval,color=GREY,ls='--',label='Timetable interval')
        ax.set_title(' → '.join(route),loc='left');ax.set(ylabel='Gap (min)')
    np.atleast_1d(axes)[0].set_ylim(0,max(gaps,default=1)*1.15)
    np.atleast_1d(axes)[0].legend(loc='upper right',frameon=False)
    np.atleast_1d(axes)[-1].set_xlabel('Departure time (h)')
    finish(fig,'08b_service_intervals','Realised gaps between successive passenger-flight departures on three example routes, shown on a common vertical scale. Each point is located at the later departure; no continuous trend is inferred between flights. Dashed lines show route timetable intervals. Delays and cancelled services can make realised gaps longer. This measures service frequency, not minimum aircraft following separation.')


def aircraft_queues(sim):
    port=next(iter(sim.ports));q=sim.ports[port].queue;c=sim.config;end=min(4,float(sim.env.now*c.time_scale_min)/60);fig,ax=figure()
    history=[(float(t*c.time_scale_min)/60,n,r) for t,n,r in q.combined_history if float(t*c.time_scale_min)/60<=end]
    history.append((end,*history[-1][1:]))
    t,n,r=np.array(history).T
    ax.fill_between(t,0,n,step='post',color=BLUE,alpha=.75,label='Actual aircraft')
    ax.fill_between(t,n,n+r,step='post',color=ORANGE,alpha=.45,label='Future reservations')
    ax.step(t,n+r,where='post',color=GREY,lw=.8)
    ax.axhline(q.capacity,color=GREY,ls='--',label='Capacity K')
    ax.set(xlabel='Time (h)',ylabel='Committed pad places',xlim=(0,end),ylim=(0,q.capacity+.5),yticks=range(q.capacity+1))
    ax.legend(ncol=3,loc='lower left',bbox_to_anchor=(0,1.01),frameon=False,fontsize=8)
    finish(fig,'09_aircraft_pad_queue',f'Detail of the first {end:g} hours at vertiport {port}. Stacked areas show actual aircraft, including service, plus future reserved places; their upper edge is the total compared with K. Exact recorded state changes are shown. Reservations are permissions, not aircraft already waiting. The complete-day network histories are shown separately in Figure 01c.')
    fig,ax=figure()
    for operation in ('takeoff','landing'):
        tickets=[t for v in sim.ports.values() for t in v.queue.tickets if t.operation==operation and t.started is not None]
        waits=np.array([float((t.started-t.arrived)*c.time_scale_min) for t in tickets])
        if not len(waits):continue
        x,count=np.unique(waits,return_counts=True);y=np.cumsum(count)/len(waits)
        ax.step(np.r_[x[0],x],np.r_[0,y],where='post',label=f'{operation.capitalize()} (n = {len(waits)})')
    ax.set(xlabel='Aircraft queue wait (min)',ylabel='Share of operations',ylim=(0,1.04),xlim=(-.08,None));percentage(ax);ax.legend(loc='lower right',frameon=False)
    finish(fig,'09b_aircraft_queue_wait','Empirical cumulative distributions of FIFO waits for takeoff and landing operations across all ports. The jump at zero gives the fraction starting service immediately, making coincident zero waits visible. Only operations with an observed service start are included. Preparation, charging and admission deferral before joining the queue are excluded. This is one illustrative run, not a confidence interval.')


def safety_summary(sim):
    rows=[d for d in sim.log.safety_checks if d['committed']];c=sim.config
    fig,ax=figure();margins=np.array([100*d['margin_soc'] for d in rows])
    if len(margins):
        x,count=np.unique(margins,return_counts=True)
        ax.step(np.r_[0,x],np.r_[0,np.cumsum(count)/len(margins)],where='post',color=BLUE)
    ax.axvline(0,color=GREY,ls='--',label='Dispatch boundary')
    ax.set(xlabel='Battery margin (percentage points)',ylabel='Share of approved assignments',ylim=(0,1.04),xlim=(-1,None));percentage(ax);ax.legend(loc='lower right',frameon=False)
    finish(fig,'10_dispatch_margin','Cumulative distribution of battery charge above the complete dispatch requirement for approved assignments in one run. Repeated mission energy and charging targets create jumps at common margins. The requirement includes mission, landing-wait allowance, a route to charging where needed, and reserve. Negative margins would prevent approval. This is a planning diagnostic, not a guarantee against the unbounded tail of exponential service delays.')
    fig,ax=figure();ax.hist([d['charger_wait_min'] for d in rows],bins=12,color=BLUE,edgecolor='white')
    ax.axvline(c.max_charger_wait_min,color=ORANGE,ls='--',label='Dispatch limit');ax.set(xlabel='Forecast charging wait (min)',ylabel='Approved assignments');ax.legend(frameon=False)
    finish(fig,'10b_charging_forecast','Forecast waiting for a charger at the time of approved assignment. The forecast uses known commitments; it is not a reserved charging appointment or an observed future wait. The 60-minute limit is an illustrative operational assumption.')
    fig,ax=figure(height=3.5)
    for i,(port,v) in enumerate(sim.ports.items()):
        waits=[float((t.started-t.arrived)*c.time_scale_min) for t in v.queue.tickets if t.operation=='landing' and t.started is not None]
        if waits:
            ax.hlines(i,0,max(waits),color=BLUE,lw=2)
            ax.scatter([max(waits)],[i],s=35,color=BLUE,label='Observed maximum' if i==0 else None)
        ax.scatter([sim.safety.hold_minutes[port]],[i],marker='D',s=35,color=ORANGE,label='Planning allowance' if i==0 else None)
    ax.set(yticks=range(len(sim.ports)),yticklabels=list(sim.ports),ylabel='Vertiport',xlabel='Landing queue wait (min)',xlim=(0,None));ax.invert_yaxis()
    ax.legend(ncol=2,loc='lower left',bbox_to_anchor=(0,1.01),frameon=False)
    finish(fig,'10c_landing_allowance','Maximum observed aircraft landing wait in the illustrative run compared with each port\'s Erlang-based planning allowance. Blue segments span zero to the sample maximum; orange diamonds show the configured 99th percentile of the conservative waiting envelope. A sample maximum below the allowance does not prove safety or validate the tail probability. A deliberately adverse safety-stop example is tested separately.')
