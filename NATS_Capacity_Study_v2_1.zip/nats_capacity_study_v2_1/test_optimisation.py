"""Checks for meaningful ranking, finite-horizon accounting and feasibility."""
from dataclasses import replace
from copy import deepcopy
import unittest
from optimisation import (Objective,Requirements,calculate_score,summarise,make_candidates,
                          evaluate,rank,pareto_ids)
from cost_optimiser_integrated import calculate_cost
from model import example_config,Simulation
from overload import passenger_arrivals
from test_safety import holding_example


def rows(completion=1.,timely=1.):
    return [dict(seed=i,arrivals=100,completion=completion,timely=timely,
        mean_observed_wait_min=30.,fleet=8,stands=16,chargers=3,
        max_utilisation=.5,max_committed_full_fraction=.02,
        safety_failure=False,complete_horizon=True,overload=False,
        peak_backlog=10,final_backlog=0) for i in range(20)]


class OptimisationTests(unittest.TestCase):
    def test_unit_and_common_weight_scaling_do_not_change_score(self):
        row=rows()[0];a=calculate_score(row)
        b=calculate_score({**row,'mean_observed_wait_min':row['mean_observed_wait_min']/60},Objective(wait_reference_min=1))
        c=calculate_score(row,Objective(weights=(7,7,7,7)))
        self.assertAlmostEqual(a['score'],b['score']);self.assertAlmostEqual(a['score'],c['score'])
        self.assertEqual(calculate_cost(row),a['score'])

    def test_worse_wait_is_not_clipped_at_reference(self):
        a=calculate_score({**rows()[0],'mean_observed_wait_min':60})
        b=calculate_score({**rows()[0],'mean_observed_wait_min':600})
        self.assertGreater(b['score'],a['score']);self.assertEqual(b['normalised']['wait'],10)

    def test_invalid_weights_and_scales_rejected(self):
        for obj in [Objective(weights=(0,0,0,0)),Objective(weights=(-1,1,1,1)),Objective(wait_reference_min=0),Objective(weights=(1,float('nan'),1,1))]:
            with self.assertRaises(ValueError):calculate_score(rows()[0],obj)

    def test_low_score_cannot_override_failed_service(self):
        bad=rows(timely=.5);good=rows()
        for r in bad:r.update(mean_observed_wait_min=0,fleet=1,stands=1,chargers=0)
        items=[dict(id='bad',summary=summarise(bad,resamples=100)),dict(id='good',summary=summarise(good,resamples=100))]
        self.assertLess(items[0]['summary']['score']['mean'],items[1]['summary']['score']['mean'])
        self.assertEqual([n for v,n in rank(items)],['good'])

    def test_failure_is_never_dropped_from_average(self):
        sample=rows();sample[0]['safety_failure']=True
        answer=summarise(sample,resamples=100)
        self.assertFalse(answer['eligible']);self.assertIsNone(answer['score']);self.assertEqual(answer['safety']['events'],1)

    def test_uncertain_service_cannot_pass_confirmation_on_mean_alone(self):
        sample=rows()
        for i,r in enumerate(sample):r['completion']=.92 if i%2 else 1.
        self.assertTrue(summarise(sample,resamples=1000)['eligible'])
        self.assertFalse(summarise(sample,confirmation=True,resamples=1000)['eligible'])

    def test_resource_margins_are_optional_and_explicit(self):
        sample=rows()
        for r in sample:r['max_utilisation']=.9
        self.assertTrue(summarise(sample,resamples=100)['eligible'])
        self.assertFalse(summarise(sample,Requirements(max_utilisation=.85),resamples=100)['eligible'])

    def test_generic_grid_and_impossible_initial_fleet(self):
        base=example_config(port_names=('A','B','C'),fleet=5)
        valid,invalid=make_candidates(base,fleets=(5,7),stands=(2,),intervals=(20,))
        self.assertEqual(len(valid),2);self.assertEqual(len(invalid),2)
        for name,c in valid:self.assertEqual(set(c.port_names),{'A','B','C'})

    def test_evaluation_includes_unfinished_passengers_and_time_scaling(self):
        c=example_config(horizon_min=90,demand_stop_min=60,total_demand_per_hour=120)
        arrivals=passenger_arrivals(c,120,919)
        a=evaluate(Simulation(c,passenger_arrivals=arrivals).run())
        b=evaluate(Simulation(replace(c,time_scale_min=3),passenger_arrivals=arrivals).run())
        self.assertEqual(a['arrivals'],len(arrivals));self.assertLess(a['completion'],1)
        for key in ['mean_observed_wait_min','completion','timely','max_utilisation','max_committed_full_fraction']:
            self.assertAlmostEqual(a[key],b[key])

    def test_early_physical_safety_stop_is_ineligible(self):
        sim=holding_example(service_minutes=200,until=250);row=evaluate(sim)
        self.assertTrue(row['safety_failure']);self.assertFalse(row['complete_horizon'])

    def test_pareto_front_removes_strictly_dominated_candidate(self):
        a=summarise(rows(),resamples=100);b=deepcopy(a);b['normalised']['fleet']+=1
        self.assertEqual(pareto_ids([dict(id='A',summary=a),dict(id='B',summary=b)]),['A'])


if __name__=='__main__':unittest.main()
