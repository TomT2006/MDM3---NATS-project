"""Regenerate figure captions and catalogue after running the notebook.
Optional dependency: reportlab. Individual chart PDF/SVG/PNG files are made by the notebook.
"""
from pathlib import Path
import json,re,sys,html
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image,PageBreak
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image as PILImage
p=Path(__file__).resolve().parent
captions=json.loads((p/'figures/captions.json').read_text())
selection=json.loads((p/'figure_selection.json').read_text())
main=selection['main_report'];titles=selection['titles']
def texescape(s):
 return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in s)
text=['REPORT FIGURES - VERSION 2.1','============================',
      'PDF: vector original for Overleaf. SVG: editable vector. PNG: 300 dpi.',
      'Copy the caption together with its figure. The uncertainty and denominators matter.','']
blocks=['% Requires \\usepackage{graphicx}. Include the figures/ folder.',
        '% Use these blocks selectively; this is an insert file, not a standalone document.']
for name,caption in sorted(captions.items()):
 text.extend([name,caption,''])
 blocks.extend([r'\begin{figure}[tbp]',r'\centering',
                r'\includegraphics[width=\linewidth]{figures/'+name+'.pdf}',
                r'\caption{'+texescape(caption)+'}',r'\label{fig:nats-v2-1-'+name.replace('_','-')+'}',r'\end{figure}',''])
(p/'NATS_Figure_Captions_v2_1.txt').write_text('\n'.join(text)+'\n')
(p/'NATS_Figure_Captions_v2_1.tex').write_text('\n'.join(blocks)+'\n')
import reportlab
fontroot=Path(reportlab.__file__).parent/'fonts'
pdfmetrics.registerFont(TTFont('DV',str(fontroot/'Vera.ttf')))
pdfmetrics.registerFont(TTFont('DV-Bold',str(fontroot/'VeraBd.ttf')))
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleV2',fontName='DV-Bold',fontSize=19,leading=24,textColor=colors.HexColor('#15334B'),spaceAfter=12))
styles.add(ParagraphStyle(name='BodyV2',fontName='DV',fontSize=10,leading=15,spaceAfter=9))
styles.add(ParagraphStyle(name='SmallV2',fontName='DV',fontSize=8.5,leading=12,textColor=colors.HexColor('#536170')))
styles.add(ParagraphStyle(name='FigureV2',fontName='DV-Bold',fontSize=12,leading=17,spaceAfter=12))
def footer(canvas,doc):
 canvas.saveState();canvas.setFont('DV',8);canvas.setFillColor(colors.HexColor('#536170'))
 canvas.drawString(54,28,'NATS capacity study - figure revision 2.1');canvas.drawRightString(541,28,str(doc.page));canvas.restoreState()

def catalogue(names,filename,title):
 story=[Paragraph(title,styles['TitleV2']),
        Paragraph('Figure revision 2.1',styles['BodyV2']),
        Paragraph(f'{len(names)} figures with captions. The 12 main-report figures are an editorial selection spanning aircraft operations, queue validation, both capacity experiments, uncertainty and optimisation. Supporting diagnostics remain in the full catalogue.',styles['BodyV2']),
        Paragraph('The simulation, raw study records, objective and statistical estimates are unchanged from version 2. Figures separate overlapping quantities and make their scales explicit. Confidence intervals concern simulation sampling under the fixed assumptions.',styles['BodyV2']),
        Paragraph('Main-report sequence',styles['FigureV2'])]
 for i,name in enumerate(main,1):
  story.append(Paragraph(f'{i:02d}. '+escape(titles[name]),styles['SmallV2']))
 story.extend([Spacer(1,14),Paragraph('Individual vector PDFs are supplied in figures/ for Overleaf; SVG and 300-dpi PNG copies are also included. Captions identify denominators, uncertainty and limits of interpretation. No smoothing is applied to make results look more regular.',styles['BodyV2'])])
 for i,name in enumerate(names,1):
  section='MAIN REPORT' if name in main else 'SUPPORTING DIAGNOSTIC'
  story.extend([PageBreak(),Paragraph(section,styles['SmallV2']),Spacer(1,5),
                Paragraph(f'{i:02d}. '+escape(titles[name]),styles['FigureV2'])])
  with PILImage.open(p/'figures'/f'{name}.png') as im:w,h=im.size
  width=475;height=width*h/w
  if height>410:height=410;width=height*w/h
  story.extend([Image(str(p/'figures'/f'{name}.png'),width=width,height=height),
                Spacer(1,15),Paragraph(escape(captions[name]),styles['BodyV2']),
                Spacer(1,6),Paragraph('Files: figures/'+escape(name)+'.pdf / .svg / .png',styles['SmallV2'])])
 SimpleDocTemplate(str(p/filename),pagesize=(595.28,841.89),leftMargin=54,rightMargin=54,
                   topMargin=48,bottomMargin=48,title=title).build(story,onFirstPage=footer,onLaterPages=footer)

catalogue(main,'NATS_Report_Figures_v2_1.pdf','NATS: main report figures')
catalogue(main+[n for n in sorted(captions) if n not in main],
          'NATS_Figure_Catalogue_v2_1.pdf','NATS: complete figure catalogue')
guide=['FIGURE SELECTION - VERSION 2.1','', 'MAIN REPORT']
guide += [f'{i:02d}. {name}: {titles[name]}' for i,name in enumerate(main,1)]
guide += ['', 'SUPPORTING DIAGNOSTICS']
guide += [f'{name}: {titles[name]}' for name in sorted(captions) if name not in main]
(p/'NATS_Figure_Guide_v2_1.txt').write_text('\n'.join(guide)+'\n')
print('Created captions, main-report selection and complete catalogue:',len(captions),'figures')
