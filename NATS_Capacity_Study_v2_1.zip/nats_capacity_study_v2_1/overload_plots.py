"""Report figures for audited whole-run overload experiments."""
from pathlib import Path
import numpy as np
from overload import load_group
from chart_style import figure,finish,errorbars,percentage,BLUE,ORANGE,GREY


def demand_design():
    t=np.array([0,2.5,5,7.5,10]);fig,ax=figure()
    ax.step(t,[.5,1.5,.5,1.5,1.5],where='post',label='Two peaks');ax.axhline(1,color=GREY,ls='--',label='Constant demand')
    ax.set(xlabel='Time (h)',ylabel='Demand multiplier',ylim=(0,1.8));ax.legend(frameon=False)
    finish(fig,'11_demand_profile','Demand profiles used for the timing sensitivity experiment. Both integrate to the same expected ten-hour demand. The paired construction also preserves each route\'s realised passenger count while shifting arrival times. Separate demand-level experiments multiply a constant rate; they do not ramp demand within a single run.')


def risk_and_service(data):
    pilot=sorted([(v['rate'],v) for k,v in data['summaries'].items() if k.startswith('pilot_')]);confirm=sorted([(v['rate'],v) for k,v in data['summaries'].items() if k.startswith('confirm_')])
    fig,ax=figure()
    for group,fmt,name in [(pilot,'o--','Pilot'),(confirm,'s','Confirmation')]:
        x=[r for r,v in group];m=np.array([v['overload']['probability'] for r,v in group]);lo=np.array([v['overload']['low'] for r,v in group]);hi=np.array([v['overload']['high'] for r,v in group])
        ax.errorbar(x,m,yerr=[m-lo,hi-m],fmt=fmt,capsize=3,label=name)
    ax.set(xlabel='Passenger demand (per hour)',ylabel='Overload probability',ylim=(-.025,1.025));percentage(ax);ax.legend(frameon=False)
    finish(fig,'12_overload_probability',f'Probability of the declared passenger-overload event before demand stops at ten hours. Pilot points use {data["plan"]["pilot_n"]} independent runs per rate; confirmation points use {data["plan"]["confirmation_n"]:,} fresh runs. Bars are exact 95% binomial intervals. The primary event requires at least 64 passengers awaiting departure for 30 minutes and net backlog growth of at least 16 passengers/hour over the preceding hour. It is an operational event definition, not proof of mathematical divergence.')
    fig,ax=figure()
    for key,name in [('served_fraction','Completed'),('timely_fraction','Departed within 60 min')]:
        x=[r for r,v in confirm];stats=[v['metrics'][key] for r,v in confirm];errorbars(ax,x,stats,label=name)
    ax.axhline(.95,color=GREY,ls='--',label='95% target');ax.set(xlabel='Passenger demand (per hour)',ylabel='Share of all passengers',ylim=(0,1.05));percentage(ax);ax.legend(frameon=False)
    finish(fig,'12b_passenger_service','Passenger service at the three independently confirmed demand levels. Points are mean daily fractions and bars are 95% whole-run bootstrap intervals from 1,000 runs per level. Completion is observed through hour 12 for arrivals before hour 10; timely service means departure within 60 minutes. All arrivals remain in the denominator. The 95% line is a project service target.')
    fig,ax=figure();rates=[r for r,v in confirm]
    errorbars(ax,rates,[v['metrics']['active_departures_per_hour'] for r,v in confirm],label='Observed departures')
    ax.plot([0,max(rates)],[0,max(rates)],'--',color=GREY,label='Departures equal demand')
    ax.axhline(data['plan']['timetable_seats_per_hour'],ls=':',color=ORANGE,label='Timetable seat ceiling')
    ax.set(xlabel='Passenger demand (per hour)',ylabel='Passenger departures (per hour)');ax.legend(frameon=False)
    finish(fig,'12c_throughput','Mean passenger departure rate during active demand, with 95% whole-run bootstrap intervals. The diagonal indicates departures matching offered demand. The baseline timetable offers 96 seats/hour, an upper bound that ignores repositioning, loading, charging, empty seats and disruptions; it is not achievable capacity. No arrivals are removed by abandonment.')


def ensemble_trajectories(data):
    for rate in data['plan']['confirmed_rates']:
        b=data['bands'][f'confirm_{rate}']
        if not b['available']:continue
        fig,ax=figure();t=np.array(b['times'])/60
        ax.fill_between(t,b['prediction_low'],b['prediction_high'],color=BLUE,alpha=.12,label='95% run range')
        ax.fill_between(t,b['simultaneous_low'],b['simultaneous_high'],color=BLUE,alpha=.45,label='95% mean band')
        ax.plot(t,b['mean'],color=BLUE,label='Mean backlog')
        ax.axhline(data['plan']['rule']['queue_limit'],color=ORANGE,ls=':',label='Queue threshold')
        ax.axvline(data['plan']['demand_stop_min']/60,color=GREY,ls='--');ax.set(xlabel='Time (h)',ylabel='Waiting passengers')
        ax.legend(ncol=2,frameon=False,fontsize=8)
        finish(fig,f'13_backlog_{rate}',f'Passenger backlog at {rate} arrivals/hour across 1,000 independent replications. The light band is the pointwise central 95% range of individual runs; the dark band is a nominal 95% simultaneous confidence band for the ensemble mean on the five-minute display grid. The vertical line marks the end of arrivals. The horizontal queue threshold is only one part of the overload rule. Vertical scales differ across the three demand figures to preserve readability.')


def time_and_sensitivity(data,folder):
    fig,ax=figure()
    for rate in data['plan']['confirmed_rates']:
        g=load_group(Path(folder)/f'confirm_{rate}');t=g['times'];event=np.array([r['overload_time_min'] if r['overload_time_min'] is not None else np.inf for r in g['rows']]);ax.step(t/60,[np.mean(event<=x) for x in t],where='post',label=f'{rate}/h')
    ax.set(xlabel='Time (h)',ylabel='Overload incidence',xlim=(0,data['plan']['demand_stop_min']/60),ylim=(0,1.03));percentage(ax);ax.legend(frameon=False)
    finish(fig,'14_time_to_overload','Fraction of all independent replications that have experienced the defined overload event by each time. Runs without an observed event remain in the denominator and are not assigned a failure time. The window ends at the ten-hour demand cutoff. This empirical cumulative incidence is distinct from the median time conditional on an event.')
    rules=data['thresholds'][f"confirm_{data['plan']['confirmed_rates'][0]}"]
    labels=['Primary rule',f"Queue ≥ {rules[1]['rule']['queue_limit']}",f"Queue ≥ {rules[2]['rule']['queue_limit']}",f"Duration {rules[3]['rule']['persistence_min']} min",f"Duration {rules[4]['rule']['persistence_min']} min",'Growth ≥ 0/h',f"Growth ≥ {rules[6]['rule']['growth_per_hour']:g}/h"]
    fig,ax=figure(height=4.4)
    for j,rate in enumerate(data['plan']['confirmed_rates']):
        rows=data['thresholds'][f'confirm_{rate}'];ax.scatter([r['probability'] for r in rows],np.arange(len(labels))+(j-1)*.15,label=f'{rate}/h',s=35)
    ax.set(yticks=range(len(labels)),yticklabels=labels,xlabel='Overload probability',xlim=(-.025,1.025));ax.invert_yaxis();percentage(ax,'x');ax.legend(frameon=False)
    finish(fig,'14b_threshold_sensitivity','Sensitivity of overload incidence to one-at-a-time changes in queue size, persistence or growth thresholds, using the same saved trajectories. The primary rule is queue at least 64 for 30 minutes and growth at least 16/hour over one hour. The alternatives are analyst-selected operating criteria; their variation does not represent uncertainty about a measured regulatory limit.')
    rates=sorted(data['plan']['confirmed_rates']);fig,axes=figure(nrows=2,height=6,sharex=True)
    for ax,selected,title in [(axes[0],rates,'All demand levels'),(axes[1],rates[:-1],'Lower-demand detail')]:
        for rate,color in zip(rates,(BLUE,ORANGE,'#009E73')):
            if rate not in selected:continue
            b=data['bands'][f'continuous_{rate}']
            if not b['available']:continue
            t=np.array(b['times'])/60
            ax.plot(t,b['mean'],label=f'{rate} passengers/h',color=color)
            ax.fill_between(t,b['simultaneous_low'],b['simultaneous_high'],color=color,alpha=.22)
        ax.set_title(title,loc='left');ax.set(ylabel='Mean backlog',ylim=(0,None),xlim=(0,t[-1]));ax.legend(frameon=False,fontsize=8)
    axes[-1].set_xlabel('Time (h)')
    finish(fig,'14c_continuing_demand','Passenger backlog under 24 hours of continuing arrivals, using 100 independent runs per demand level. The upper panel compares all levels; the lower repeats the lower-demand curves on an expanded vertical scale. Shading gives nominal 95% simultaneous mean bands on the display grid. No demand cutoff or abandonment drains the queue. Growth is evidence within the tested horizon, not a proof about infinite time.')


def profile_comparison(data,folder):
    rate=data['plan']['transition_selected_from_independent_pilot'];peak=load_group(Path(folder)/f'peaks_{rate}');constant=load_group(Path(folder)/f'confirm_{rate}');seeds=set(r['seed'] for r in peak['rows']);ix=[i for i,r in enumerate(constant['rows']) if r['seed'] in seeds]
    fig,ax=figure()
    for g,indices,label in [(constant,ix,'Constant'),(peak,list(range(len(peak['rows']))),'Two peaks')]:ax.plot(g['times']/60,g['queue'][indices].sum(axis=2).mean(axis=0),label=label)
    ax.set(xlabel='Time (h)',ylabel='Mean waiting passengers');ax.legend(frameon=False)
    finish(fig,'16_demand_timing',f'Constant and two-peak passenger demand at a common mean of {rate}/hour. The 100 paired runs preserve the same realised passenger counts by route and share component random streams. Differences therefore concern arrival timing and its interaction with operations, not simply greater total demand. Paired waiting-time differences and their bootstrap interval are reported in the notebook.')


def bootstrap_distribution(data,folder):
    rate=data['plan']['transition_selected_from_independent_pilot'];g=load_group(Path(folder)/f'confirm_{rate}');values=np.array([r['mean_observed_wait_min'] for r in g['rows']]);rng=np.random.default_rng(20261109);means=[]
    for start in range(0,5000,128):means.extend(values[rng.integers(0,len(values),size=(min(128,5000-start),len(values)))].mean(axis=1))
    for sample,stem,xlabel,caption in [(values,'17_daily_variation','Daily mean waiting (min)',f'Distribution of observed mean passenger waiting across 1,000 independent runs at {rate} arrivals/hour. Every offered passenger contributes waiting until departure or observation cutoff. This distribution describes day-to-day simulation variability, not uncertainty in an estimated mean.'),(means,'17b_bootstrap_mean','Bootstrap mean waiting (min)','Distribution of 5,000 bootstrap means obtained by resampling whole independent replications with replacement. Dashed lines mark the 2.5th and 97.5th percentiles. The narrow distribution measures Monte Carlo uncertainty in the mean, not the range of individual passenger waits or real-world model uncertainty.')]:
        fig,ax=figure();ax.hist(sample,bins=30,color=BLUE,edgecolor='white')
        if sample is means:
            for value in np.quantile(means,[.025,.975]):ax.axvline(value,color=ORANGE,ls='--')
        ax.set(xlabel=xlabel,ylabel='Frequency');finish(fig,stem,caption)
